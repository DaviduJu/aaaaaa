import {NavLink} from "react-router-dom";
import './Nav.css';

export const Nav = ()=>{
    return(
        <div>
            <nav>
                <ul>
                    
                    <li><NavLink to= '/'> Home </NavLink></li>
                    <li><NavLink to= '/Pagina2'> Pagina2</NavLink></li>
                    <li><NavLink to= '/Contactos'> Contactos</NavLink></li>
                    <li><NavLink to= '/Categorias'> Categorias</NavLink></li>
                </ul>
            </nav>
        </div>
    )
}