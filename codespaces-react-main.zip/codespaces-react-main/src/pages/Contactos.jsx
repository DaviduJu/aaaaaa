import { Link} from "react-router-dom";

export function Contactos (){
    return(
        <div>
            <h1>
                Estoy en contactos
            </h1>
            <Link to={"/"}>Ir al Home </Link>
            
        </div>
    )

}