import { Link } from "react-router-dom";

export const PagNoVale = ()=>{
    return(
        <div>
            <h1>
                Pagina no valida error 404
            </h1>
            <Link to={"/"}>Ir al Home </Link>
            
        </div>
    )

}